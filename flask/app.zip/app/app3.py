from flask import Flask, request, jsonify, g
#from flask_sqlalchemy import SQLAlchemy

from saramin_c import get_recruit #크롤링 파일 가져오기
from data_cleaning import recruit_count
from data_cleaning import get_job_to_stack
from data_cleaning import get_stack_to_stack
from db_form import recruit_db
from db_form import task_db
from db_form import stack_db
import json



app = Flask(__name__)


#데이터 조회
@app.route('/recruit/new', methods = ['POST'])
def recruit_new():
	a_recruit = get_recruit() #saramin crawling
	recruit_db(a_recruit)
	
	return {'commit': 'success'} 

#wanted 데이터 통계



@app.route('/Stacks/update', methods = ['POST'])
def Stack():
	f = open('raw_data.json', 'r')
	rdr = json.load(f)
	task_result = get_job_to_stack(rdr)
	task_db(task_result)
	
	stack_result = get_stack_to_stack(rdr)
	stack_db(stack_result)
	f.close()
	#with open('JobToStack0405.json','w') as f:
	#	json.dump(result ,f,default=str,ensure_ascii=False)
	return {'commit':'success'}


if __name__ == "__main__":
	app.debug = True
	app.run()
